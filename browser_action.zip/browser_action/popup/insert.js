console.log("good");

var a = document.getElementsByClassName("_42ft _4jy0 _4jy4 _4jy2 selected _51sy");
a[0].click();
