(function(){
    'use strict';

   console.log("go");

   var backgroundP = chrome.extension.getBackgroundPage();

   document.querySelector('h1').addEventListener('click', function(){

    backgroundP.injectScript();

     /*chrome.tabs.create({
       //'url': 'https://goo.gl/bBfbrp'
       'url': 'http://paranormalcode.com'
     }, function(tab){
       console.log("Z");
       chrome.tabs.executeScript(tab.id, {
         runAt: 'document_end',
         code: 'console.log("Hi");'
       });
     });
*/
   });

}());
