console.log("Hi!");

function injectScript() {
  chrome.tabs.create({url : 'https://goo.gl/bBfbrp'}, function(tab) {
    chrome.tabs.executeScript(tab.id, {file: 'popup/insert.js'});
  });
};
